package com.example.kaiya.movierater

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import android.text.TextUtils
import android.widget.RadioGroup

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun onCheckBoxClicked(v: View){
        if(chkbxRating.isChecked == true)
        {
            chkbxReason.setVisibility(View.VISIBLE)
        }
        else
        {
            chkbxReason.setVisibility(View.INVISIBLE)

        }
    }

    fun btnAdd(v: View){

        var language: String = "";

        if(english.isChecked)
        {
            language = "English"
        }
        else if(chinese.isChecked)
        {
            language = "Chinese"
        }
        else if(malay.isChecked)
        {
            language = "Malay"
        }
        else if(tamil.isChecked)
        {
            language = "Tamil"
        }


        var all_reason: String = "";

        if(Violence.isChecked == true && LangUsed.isChecked == true)
        {
            all_reason = "Violence\nLanguage Used"
        }
        else if(Violence.isChecked == true)
        {
            all_reason = "Violence"
        }
        else if(LangUsed.isChecked == true)
        {
            all_reason = "Language Used"
        }


        if(TextUtils.isEmpty(movie_name.getText()) or TextUtils.isEmpty(movie_desc.getText()) or TextUtils.isEmpty(movie_date.getText())){
            movie_name.setError("Field Empty!");
            movie_desc.setError("Field Empty!");
            movie_date.setError("Field Empty!");
        }else{
            Toast.makeText(this,
                "Title = "+ movie_name.text + "\nDescription = " + movie_desc.text + "\nRelease Date = " +movie_date.text + "\nLanguage = " + language + "\nSuitable for all ages = " + chkbxRating.isChecked + "\nReason: \n" + all_reason,
                Toast.LENGTH_LONG).show()
        }



    }

}
